boulangerie-lb/
├── index.html (Page présentation)
├── produits.html (Page liste produits)
├── contact.html (Page formulaire)
├── assets/
│ ├── css/
│ │ ├── reset.css
│ │ ├── variables.css
│ │ ├── base.css
│ │ ├── layout.css
│ │ ├── components.css
│ │ └── pages.css
│ ├── js/
│ │ ├── main.js
│ │ ├── burger.js
│ │ ├── carousel.js
│ │ └── map.js
│ ├── assets/
│ │ └── logo.png (à remplacer par votre logo)
├── .gitignore
└── README.md
