consigne du TP :
Réalisez une maquete et l'intégration du site d'un commerçant local de votre choix (boulangerie, restaurant, food truck, libraire, etc...)
Réalisez 1 à 3 wireframe en mode desktop et mobile
Réalisez l'identité visuelle de votre site
Réalisez 1 à 3 page maquetté en mode desktop et mobile
Intégrez le site en HTML/CSS (js si besoin)
Le site doit être responsive

Rendu via github + lien figma ou code source zipé + lien figma
Date de rendu : dimanche soir 23h59 sur ypareo
Grille d'évaluation en pièce jointe
